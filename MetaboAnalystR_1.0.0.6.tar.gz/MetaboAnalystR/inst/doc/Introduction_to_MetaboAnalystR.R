## ---- eval=FALSE---------------------------------------------------------
#  # Load MetaboAnalystR
#  library(MetaboAnalystR)
#  

## ---- eval=FALSE---------------------------------------------------------
#  # Create objects for storing processed data
#  mSet <- InitDataObjects("conc", "stat", FALSE)
#  
#  # Read in the data and fill in the dataSet list
#  
#  mSet <- Read.TextData(mSet, "http://www.metaboanalyst.ca/resources/data/human_cachexia.csv", "rowu", "disc")
#  
#  # To view messages from the data import and processing
#  mSet$dataSet$read.msg
#  
#  # Example of messages
#  [1] "Samples are in rows and features in columns"
#  [2] "The uploaded file is in comma separated values (.csv) format."
#  [3] "The uploaded data file contains 77 (samples) by 63 (compounds) data matrix."

## ---- eval=FALSE---------------------------------------------------------
#  mSet <- InitDataObjects("pktable", "stat", FALSE)
#  
#  mSet <- Read.TextData(mSet, "http://www.metaboanalyst.ca/resources/data/NMRpeaklistskidney.csv", "rowu", "disc")

## ---- eval=FALSE---------------------------------------------------------
#  # Create an object for storing processed data
#  mSet <- InitDataObjects("msspec", "stat", FALSE)
#  
#  # Unzip the uploaded zip file/s, remove it and save it as "upload"
#  mSet <- UnzipUploadedFile(mSet, "lcms_netcdf.zip", "upload", T)
#  
#  # Read the unzipped LC/GC-MS spectra (.netCDF, .mzXML, mzData)
#  # Detect, align, and group peaks
#  # Fill in the object (dataSet)
#  mSet <- Read.MSspec(mSet, "upload", "bin", 30.0, 30.0)

## ---- eval=FALSE---------------------------------------------------------
#  # Perform retention time correction and re-group peaks
#  mSet <- MSspec.rtCorrection(mSet, 30.0)
#  
#  # Fill in missing peaks
#  mSet <- MSspec.fillPeaks(mSet)
#  
#  # Create the MS spectra data matrix of peak values for each group for further processing and analysis
#  mSet <- SetupMSdataMatrix(mSet, "into")
#  
#  # Option to view messages from filling in missing peaks and creating the MS matrix
#  mSet$dataSet$xset.msg
#  
#  # Example of messages
#  [1] "A total of 6069 peaks were detected from these samples"
#  [2] "with an average of 505.75 peaks per spectrum."
#  [3] "These peaks were aligned 410 groups according to their mass and retention time."
#  [4] "Please note, some peaks were excluded if they appear in only a few samples."
#  
#  # To evaluate if processing of spectral data is ok
#  mSet <- IsSpectraProcessingOK(mSet)

## ---- eval=FALSE---------------------------------------------------------
#  # Create an object for storing processed data
#  mSet <- InitDataObjects("mspeak", "stat", FALSE)
#  
#  # Unzips the uploaded zip file/s, removes it and saves it as "upload"
#  mSet <- UnzipUploadedFile(mSet, "lcms_3col_peaks.zip", "upload", F)
#  
#  # Read peak lists/intensity files
#  mSet <- Read.PeakList(mSet, "upload")

## ---- eval=FALSE---------------------------------------------------------
#  # Perform grouping of peaks
#  mSet <- GroupPeakList(mSet, 0.025, 30.0)
#  
#  # Form peak groups
#  mSet <- SetPeakList.GroupValues(mSet)
#  
#  # View message resulting from peak grouping (Optional, though for your benefit)
#  mSet$dataSet$proc.msg
#  

## ---- eval=FALSE---------------------------------------------------------
#  
#  # Run the sanity check, it will return a 1 if the data is suitable for subsequent analyses.
#  mSet <- SanityCheckData(mSet)
#  [1] 1
#  
#  # View messages collected from running the sanity check.
#  mSet$dataSet$check.msg
#  
#  # Example of collected messages
#   [1] "Samples are in rows and features in columns"
#   [2] "The uploaded file is in comma separated values (.csv) format."
#   [3] "The uploaded data file contains 77 (samples) by 63 (compounds) data matrix."
#   [4] "2 groups were detected in samples."
#   [5] "Samples are not paired."
#   [6] "All data values are numeric."
#   [7] "A total of 0 (0%) missing values were detected."

## ---- eval=FALSE---------------------------------------------------------
#  # Replace missing/zero values with a minimum positive value
#  mSet <- ReplaceMin(mSet)
#  
#  # View messages collected during ReplaceMin()
#  mSet$dataSet$replace.msg
#  
#  # Example of message for replacing values
#  [1] "Zero or missing variables were replaced with a small value: 0.395"
#  

## ---- eval=FALSE---------------------------------------------------------
#  # Step 1: Remove features containing a user-defined % cut-off of missing values
#  mSet <- RemoveMissingPercent(mSet, percent=0.5)
#  
#  # Step 2: Remove variables with missing values
#  mSet <- ImputeVar(mSet, method="exclude")
#  
#  # Alternative Step 2: Replace missing values with KNN imputed values
#  mSet <- ImputeVar(mSet, method="knn")

## ---- eval=FALSE---------------------------------------------------------
#  # Check if the sample size is too small, returns a 0 if the data passes the check
#  mSet<-IsSmallSmplSize(mSet)
#  [1] 0

## ---- eval=FALSE---------------------------------------------------------
#  # 1) Perform Probabilistic Quotient Normalization based upon a reference sample
#  mSet<-Normalization(mSet, "ProbNormF", "NULL", "NULL", "PIF_178", ratio=FALSE, ratioNum=20)
#  
#  # 2) Normalize by reference feature
#  mSet<-Normalization(mSet, "CompNorm", "NULL", "NULL", "1,6-Anhydro-beta-D-glucose", ratio=FALSE, ratioNum=20)
#  
#  # 3) Perform quantile normalization, log transformation, and mean-center scaling
#  mSet<-Normalization(mSet, "QuantileNorm", "LogNorm", "MeanCenter", ref=NULL, ratio=FALSE, ratioNum=20)

## ---- eval=FALSE---------------------------------------------------------
#  # View feature normalization
#  mSet<-PlotNormSummary(mSet, "feature_norm", format="png", dpi=300, width=0)
#  
#  # View sample normalization
#  mSet<-PlotSampleNormSummary(mSet, "sample_norm", format="pdf", width=NA)
#  

## ---- eval=FALSE---------------------------------------------------------
#  # Filter variables based on the median absolute deviation
#  mSet <- FilterVariable(mSet, "mad", "F", 15)
#  
#  # Filter variables using QC-samples and a RDS threshold of 25
#  mSet <- FilterVariable(mSet, "none", "T", 25)

## ---- eval=FALSE---------------------------------------------------------
#  # Remove a sample from the data set, in this case sample "PIF_178"
#  mSet <- UpdateSampleItems(mSet, "PIF_178")
#  
#  # Remove a feature from the data set
#  mSet <- UpdateFeatureItems(mSet, "2-Aminobutyrate")
#  
#  # Remove a group from the data set, in this case remove the "control" samples
#  mSet <- UpdateGroupItems(mSet, "control")

