## ---- eval=FALSE---------------------------------------------------------
#  
#  # Create objects for storing processed data from the network explorer module
#  mSet <- InitDataObjects("conc", "network", FALSE)
#  
#  # Set organism to human, at the moment only human data can be accomodated
#  mSet<-SetOrganism(mSet, "hsa")
#  
#  # Set geneListFile as a file containing your gene list
#  geneListFile<-"replace_with_your_file_name"
#  
#  # Read in the geneListFile
#  # This will import a plain text file as single character string
#  geneList<-readChar(geneListFile, file.info(geneListFile)$size)
#  
#  # Perform gene ID mapping
#  mSet<-PerformIntegGeneMapping(mSet, geneList, "hsa", "entrez");
#  
#  # Set cmpdListFile as a file containing your metablolite list
#  cmpdListFile <- "replace_with_your_file_name"
#  
#  # Read in the cmpdListFile
#  # This will import a plain text file as single character string
#  cmpdList<-readChar(cmpdListFile, file.info(cmpdListFile)$size)
#  
#  # Perform compound ID mapping
#  mSet<-PerformIntegCmpdMapping(mSet, cmpdList, "hsa", "kegg");
#  
#  # Create the mapping results table
#  mSet<-CreateMappingResultTable(mSet)
#  
#  # Prepare the data for network analysis, saves a .json file that can be uploaded
#  # to external sites/packages to view the network
#  mSet<-PrepareNetworkData(mSet);
#  
#  # After selecting KEGG global metabolic network
#  mSet<-PrepareQueryJson(mSet)
#  
#  # Perform enrichment analysis based on uploaded KOs (KEGG Global Metabolic Network)
#  PerformKOEnrichAnalysis_KO01100("pathway", "network_enrichment_pathway_0");
#  
#  # Perform mapping for interaction network
#  SearchNetDB("pheno", "gene_metabolites", FALSE, 0.5)
#  

## ---- eval=FALSE---------------------------------------------------------
#  # Create Biomarker Sweave report
#  CreatePDFReport(mSet, "User Name")
#  
#  # To save all files created during your session
#  SaveTransformedData(mSet)
#  

